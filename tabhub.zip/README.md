# TabHub（WebSocket 版）

Chromeのプロファイルをまたいでタブを検索し、タブに一時的な名前を付けるための拡張機能とローカルデーモンです。レジストリは一切変更しません。

## 構成

```
[プロファイルA] 拡張 ─┐
[プロファイルB] 拡張 ─┼─ ws://127.0.0.1:47821/ws ─ tabhub_daemon.py（1プロセス）
[プロファイルC] 拡張 ─┘
```

- デーモンは Python 3.9 以上の標準ライブラリだけで動きます（pip 不要）。
- 待ち受けは 127.0.0.1 のみです。WebSocket は Origin が `chrome-extension://` のものだけを受け付け、Host ヘッダもループバック名以外を拒否します。
- CLI 用の HTTP API は、`%LOCALAPPDATA%\tabhub\token` のトークンを必須にしています。
- タブ名は `chrome.storage.session` に保存されます。ブラウザを再起動すると消え、タブを閉じたときもそのタブの名前は削除されます。

## セットアップ

1. デーモンを起動します。
   ```
   python daemon\tabhub_daemon.py serve
   ```
   ログは `%LOCALAPPDATA%\tabhub\daemon.log` に出力されます。
2. `chrome://extensions` でデベロッパーモードを有効にし、「パッケージ化されていない拡張機能を読み込む」で `extension\` を読み込みます。すべてのプロファイルで同じフォルダを読み込んでください。拡張IDが揃います。
3. （任意）接続元をこの拡張に限定する場合は、拡張IDを指定して起動します。
   ```
   python daemon\tabhub_daemon.py serve --allow-id <拡張ID>
   ```
4. （任意）ログオン時に自動起動させるには、次を実行します。
   ```
   python daemon\tabhub_daemon.py startup install
   ```
   スタートアップフォルダ（`shell:startup`）に `TabHub.cmd` を置くだけで、レジストリには触れません。`pythonw` で起動するので、コンソールウィンドウは残りません。解除は `startup uninstall` です。`--allow-id` を使う場合は、作成された `TabHub.cmd` の末尾に追記してください。

ポートを変える場合は、デーモンの `--port` と `extension/background.js` の `DAEMON_PORT` の両方を変更します。

## 使い方

- `Alt+Shift+K`（`chrome://extensions/shortcuts` で変更できます）またはツールバーのアイコンでポップアップを開きます。
- 検索欄の語はスペース区切りの AND 検索です。名前・タイトル・URL・プロファイル表示名が対象で、全角と半角は区別しません。
- `↑↓` で選択、`Enter` で移動、`F2` で選択中のタブに名前を付けます（空にすると解除）。
- **開いたばかりのタブに名前を付ける**: `Alt+Shift+N` で、現在のタブの名前入力欄が開いた状態のポップアップが出ます。入力して `Enter` で確定すると閉じます。ポップアップを `Alt+Shift+K` で開いてすぐ `F2` を押しても同じ操作になります。
- フッターで、このプロファイルの表示名を変更できます。

## CLI（デーモン起動中）

```
python daemon\tabhub_daemon.py list [検索語...]        # TSV: instance, tabId, profile, name, title, url
python daemon\tabhub_daemon.py activate <instance> <tabId>
python daemon\tabhub_daemon.py rename <instance> <tabId> 名前
```

## 既知の制約

- デーモンが止まっていると、各プロファイルの Service Worker コンソールに WebSocket の接続失敗が出ます（30秒ごとに再接続を試みるため）。この場合、ポップアップには自分のプロファイルのタブだけが表示されます。
- 別プロファイルのウィンドウを前面に出す操作は、Windows のフォアグラウンド制限によって、タスクバーの点滅で止まることがあります。
- シークレットウィンドウは対象外です。
- Chrome 127 以降が必要です（`Alt+Shift+N` でポップアップを開く `chrome.action.openPopup` のため）。
