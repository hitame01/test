#!/usr/bin/env python3
"""TabHub daemon — Chromeプロファイル横断タブ検索のローカルハブ（標準ライブラリのみ）

各プロファイルの拡張機能が ws://127.0.0.1:<port>/ws に接続してタブ一覧を送り、
このプロセスが集約・中継する。レジストリは使わない。

usage:
  tabhub_daemon.py [serve] [--port N] [--allow-id EXTENSION_ID ...]
  tabhub_daemon.py list [検索語...]                 全プロファイルのタブを TSV で出力
  tabhub_daemon.py activate <instance> <tabId>
  tabhub_daemon.py rename <instance> <tabId> [名前]
  tabhub_daemon.py startup install|uninstall        Windowsのスタートアップフォルダに登録/解除
"""
from __future__ import annotations

import argparse
import asyncio
import base64
import hashlib
import json
import logging
import logging.handlers
import os
import pathlib
import secrets
import struct
import sys
import time
import unicodedata
import urllib.error
import urllib.request

DEFAULT_PORT = 47821
WS_GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"
MAX_MESSAGE = 16 * 1024 * 1024
log = logging.getLogger("tabhub")


# ---------------- 状態ディレクトリ・トークン ----------------
def state_dir() -> pathlib.Path:
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    elif sys.platform == "darwin":
        base = os.path.expanduser("~/Library/Application Support")
    else:
        base = os.environ.get("XDG_STATE_HOME") or os.path.expanduser("~/.local/state")
    d = pathlib.Path(base) / "tabhub"
    d.mkdir(parents=True, exist_ok=True)
    return d


def load_token(d: pathlib.Path) -> str:
    """CLI 用 HTTP API の認証トークン。ユーザーのローカル領域にだけ置く。"""
    p = d / "token"
    for _ in range(50):
        try:
            tok = p.read_text().strip()
            if tok:
                return tok
        except FileNotFoundError:
            try:
                fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                tok = secrets.token_hex(16)
                with os.fdopen(fd, "w") as f:
                    f.write(tok)
                return tok
            except FileExistsError:
                pass
        time.sleep(0.02)
    raise RuntimeError(f"token file unreadable: {p}")


# ---------------- WebSocket（RFC 6455 の必要最小限） ----------------
def ws_frame(opcode: int, payload: bytes) -> bytes:
    n = len(payload)
    head = bytes([0x80 | opcode])
    if n < 126:
        head += bytes([n])
    elif n < 65536:
        head += bytes([126]) + struct.pack("!H", n)
    else:
        head += bytes([127]) + struct.pack("!Q", n)
    return head + payload


def unmask(data: bytes, mask: bytes) -> bytes:
    n = len(data)
    if n == 0:
        return data
    key = (mask * (n // 4 + 1))[:n]
    return (int.from_bytes(data, "big") ^ int.from_bytes(key, "big")).to_bytes(n, "big")


class WsConn:
    def __init__(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter, ext_id: str):
        self.reader, self.writer, self.ext_id = reader, writer, ext_id
        self.lock = asyncio.Lock()
        self.instance: str | None = None
        self.label = ""
        self.tabs: list = []
        self.closed = False

    async def _write(self, frame: bytes):
        async with self.lock:
            if self.closed:
                return
            self.writer.write(frame)
            await self.writer.drain()

    async def send(self, obj):
        await self._write(ws_frame(0x1, json.dumps(obj, ensure_ascii=False).encode("utf-8")))

    async def close(self, code: int = 1000):
        if self.closed:
            return
        try:
            await self._write(ws_frame(0x8, struct.pack("!H", code)))
        except OSError:
            pass
        self.closed = True
        self.writer.close()

    async def recv(self):
        """テキストメッセージ1件を返す。切断時は None。"""
        buf, msg_op = b"", None
        while True:
            b1, b2 = await self.reader.readexactly(2)
            fin, op = b1 & 0x80, b1 & 0x0F
            n = b2 & 0x7F
            if n == 126:
                n = struct.unpack("!H", await self.reader.readexactly(2))[0]
            elif n == 127:
                n = struct.unpack("!Q", await self.reader.readexactly(8))[0]
            if n > MAX_MESSAGE:
                await self.close(1009)
                return None
            mask = await self.reader.readexactly(4) if b2 & 0x80 else b""
            data = await self.reader.readexactly(n)
            if mask:
                data = unmask(data, mask)
            if op == 0x8:            # close
                await self.close()
                return None
            if op == 0x9:            # ping
                await self._write(ws_frame(0xA, data))
                continue
            if op == 0xA:            # pong
                continue
            if op in (0x1, 0x2):
                msg_op, buf = op, data
            elif op == 0x0:
                buf += data
            if len(buf) > MAX_MESSAGE:
                await self.close(1009)
                return None
            if fin and msg_op is not None:
                return buf.decode("utf-8") if msg_op == 0x1 else None


# ---------------- デーモン本体 ----------------
class Daemon:
    def __init__(self, port: int, allow_ids: set[str], token: str):
        self.port, self.allow_ids, self.token = port, allow_ids, token
        self.conns: dict[str, WsConn] = {}

    async def handle(self, reader, writer):
        try:
            head = await asyncio.wait_for(reader.readuntil(b"\r\n\r\n"), 10)
        except (asyncio.TimeoutError, asyncio.IncompleteReadError, asyncio.LimitOverrunError, OSError):
            writer.close()
            return
        lines = head.decode("latin-1").split("\r\n")
        try:
            method, path, _ = lines[0].split(" ", 2)
        except ValueError:
            writer.close()
            return
        headers = {}
        for line in lines[1:]:
            if ":" in line:
                k, v = line.split(":", 1)
                headers[k.strip().lower()] = v.strip()

        # DNS リバインディング対策: Host はループバック名のみ受け付ける
        if headers.get("host", "") not in (f"127.0.0.1:{self.port}", f"localhost:{self.port}"):
            return await self.http(writer, 403, {"error": "bad host"})

        try:
            if headers.get("upgrade", "").lower() == "websocket" and path == "/ws":
                await self.websocket(reader, writer, headers)
            elif path.startswith("/api/"):
                await self.api(reader, writer, method, path, headers)
            else:
                await self.http(writer, 404, {"error": "not found"})
        except (asyncio.IncompleteReadError, ConnectionError, OSError):
            pass
        finally:
            if not writer.is_closing():
                writer.close()

    async def http(self, writer, status: int, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        reason = {200: "OK", 400: "Bad Request", 401: "Unauthorized", 403: "Forbidden", 404: "Not Found"}.get(status, "")
        writer.write(f"HTTP/1.1 {status} {reason}\r\nContent-Type: application/json; charset=utf-8\r\n"
                     f"Content-Length: {len(body)}\r\nConnection: close\r\n\r\n".encode() + body)
        try:
            await writer.drain()
        except OSError:
            pass
        writer.close()

    # --- 拡張機能との WebSocket ---
    async def websocket(self, reader, writer, headers):
        origin = headers.get("origin", "")
        prefix = "chrome-extension://"
        ext_id = origin[len(prefix):] if origin.startswith(prefix) else ""
        if not ext_id or (self.allow_ids and ext_id not in self.allow_ids):
            log.warning("rejected websocket from origin %r", origin)
            return await self.http(writer, 403, {"error": "origin not allowed"})
        key = headers.get("sec-websocket-key", "")
        if not key:
            return await self.http(writer, 400, {"error": "missing key"})
        accept = base64.b64encode(hashlib.sha1((key + WS_GUID).encode()).digest()).decode()
        writer.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                      f"Sec-WebSocket-Accept: {accept}\r\n\r\n").encode())
        await writer.drain()

        conn = WsConn(reader, writer, ext_id)
        try:
            while True:
                text = await conn.recv()
                if text is None:
                    break
                try:
                    msg = json.loads(text)
                except ValueError:
                    continue
                await self.on_message(conn, msg)
        finally:
            if conn.instance and self.conns.get(conn.instance) is conn:
                del self.conns[conn.instance]
                log.info("disconnected: %s (%s)", conn.label, conn.instance)
            conn.closed = True

    async def on_message(self, conn: WsConn, msg: dict):
        t = msg.get("type")
        if t == "hello":
            conn.instance = str(msg.get("instance") or "")
            conn.label = str(msg.get("label") or "")
            old = self.conns.get(conn.instance)
            self.conns[conn.instance] = conn
            if old is not None and old is not conn:
                await old.close()
            log.info("connected: %s (%s) ext=%s", conn.label, conn.instance, conn.ext_id)
            await conn.send({"type": "ready"})
        elif t == "tabs":
            conn.tabs = msg.get("tabs") or []
            if msg.get("label"):
                conn.label = msg["label"]
        elif t == "ping":
            await conn.send({"type": "pong"})
        elif t == "request":
            asyncio.create_task(self.on_request(conn, msg))

    async def on_request(self, conn: WsConn, msg: dict):
        rid = msg.get("id")
        try:
            cmd = msg.get("cmd")
            if cmd == "list_others":
                data = [self.snapshot(c) for c in self.conns.values() if c is not conn]
            elif cmd == "remote":
                await self.exec(msg.get("target"), msg.get("ext_cmd"), msg.get("args") or {})
                data = None
            else:
                raise ValueError(f"unknown cmd: {cmd}")
            await conn.send({"type": "response", "id": rid, "ok": True, "data": data})
        except Exception as e:  # noqa: BLE001
            await conn.send({"type": "response", "id": rid, "ok": False, "error": str(e)})

    @staticmethod
    def snapshot(c: WsConn) -> dict:
        return {"instance": c.instance, "label": c.label, "self": False, "tabs": c.tabs}

    async def exec(self, instance, cmd, args):
        if cmd not in ("activate", "rename"):
            raise ValueError(f"unknown command: {cmd}")
        target = self.conns.get(instance)
        if target is None:
            raise LookupError("そのプロファイルは接続していません")
        await target.send({"type": "command", "cmd": cmd, "args": args})

    # --- CLI 用 HTTP API（トークン必須。カスタムヘッダなのでWebページからは送れない） ---
    async def api(self, reader, writer, method, path, headers):
        if not secrets.compare_digest(headers.get("x-tabhub-token", ""), self.token):
            return await self.http(writer, 401, {"error": "bad token"})
        if method == "GET" and path == "/api/tabs":
            return await self.http(writer, 200, {"ok": True, "instances": [self.snapshot(c) for c in self.conns.values()]})
        if method == "POST" and path == "/api/exec":
            n = int(headers.get("content-length", "0") or 0)
            if n > 1 << 20:
                return await self.http(writer, 400, {"error": "too large"})
            try:
                req = json.loads(await reader.readexactly(n))
                await self.exec(req.get("instance"), req.get("cmd"), req.get("args") or {})
            except Exception as e:  # noqa: BLE001
                return await self.http(writer, 400, {"ok": False, "error": str(e)})
            return await self.http(writer, 200, {"ok": True})
        return await self.http(writer, 404, {"error": "not found"})


def setup_logging(d: pathlib.Path):
    log.setLevel(logging.INFO)
    fh = logging.handlers.RotatingFileHandler(d / "daemon.log", maxBytes=512 * 1024, backupCount=2, encoding="utf-8")
    fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    log.addHandler(fh)
    if sys.stderr is not None:          # pythonw では stderr が無い
        log.addHandler(logging.StreamHandler())


async def serve(port: int, allow_ids: set[str]):
    d = state_dir()
    setup_logging(d)
    daemon = Daemon(port, allow_ids, load_token(d))
    try:
        server = await asyncio.start_server(daemon.handle, "127.0.0.1", port)
    except OSError as e:
        log.error("port %d を使えません（すでに起動している可能性があります）: %s", port, e)
        sys.exit(1)
    log.info("TabHub daemon listening on ws://127.0.0.1:%d/ws (allow-id: %s)", port, ", ".join(allow_ids) or "any extension")
    async with server:
        await server.serve_forever()


# ---------------- CLI ----------------
def api_call(port: int, method: str, path: str, body=None):
    token = load_token(state_dir())
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(f"http://127.0.0.1:{port}{path}", data=data, method=method,
                                 headers={"X-TabHub-Token": token, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=3) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        sys.exit(f"error: {json.loads(e.read()).get('error', e)}")
    except urllib.error.URLError:
        sys.exit(f"error: デーモン(127.0.0.1:{port})に接続できません。先に起動してください")


def norm(s):
    return unicodedata.normalize("NFKC", s or "").lower()


def startup(action: str):
    if sys.platform != "win32":
        sys.exit("startup は Windows 専用です")
    folder = pathlib.Path(os.environ["APPDATA"]) / "Microsoft/Windows/Start Menu/Programs/Startup"
    target = folder / "TabHub.cmd"
    if action == "uninstall":
        target.unlink(missing_ok=True)
        print("removed:", target)
        return
    pyw = pathlib.Path(sys.executable).with_name("pythonw.exe")
    exe = pyw if pyw.exists() else pathlib.Path(sys.executable)
    script = pathlib.Path(__file__).resolve()
    target.write_text(f'@echo off\r\nstart "" "{exe}" "{script}" serve\r\n', encoding="utf-8")
    print("created:", target)
    print("次回ログオン時から自動起動します。今すぐ起動するには:", f'"{exe}" "{script}" serve')


def main():
    ap = argparse.ArgumentParser(description="TabHub daemon")
    ap.add_argument("--port", type=int, default=DEFAULT_PORT)
    sub = ap.add_subparsers(dest="cmd")
    s = sub.add_parser("serve")
    s.add_argument("--allow-id", action="append", default=[], help="接続を許可する拡張ID（複数可。省略時は任意の拡張）")
    l = sub.add_parser("list")
    l.add_argument("terms", nargs="*")
    a = sub.add_parser("activate")
    a.add_argument("instance")
    a.add_argument("tab_id", type=int)
    r = sub.add_parser("rename")
    r.add_argument("instance")
    r.add_argument("tab_id", type=int)
    r.add_argument("name", nargs="*")
    st = sub.add_parser("startup")
    st.add_argument("action", choices=["install", "uninstall"])
    ns = ap.parse_args()

    if ns.cmd in (None, "serve"):
        asyncio.run(serve(ns.port, set(getattr(ns, "allow_id", []) or [])))
    elif ns.cmd == "list":
        if sys.stdout is not None:
            sys.stdout.reconfigure(encoding="utf-8")
        terms = [norm(t) for t in ns.terms]
        for ins in api_call(ns.port, "GET", "/api/tabs")["instances"]:
            for t in ins["tabs"]:
                hay = "\n".join(norm(x) for x in (t.get("name"), t.get("title"), t.get("url"), ins["label"]))
                if all(term in hay for term in terms):
                    row = [ins["instance"], str(t["id"]), ins["label"], t.get("name", ""), t.get("title", ""), t.get("url", "")]
                    print("\t".join(str(c).replace("\t", " ").replace("\n", " ") for c in row))
    elif ns.cmd == "activate":
        api_call(ns.port, "POST", "/api/exec", {"instance": ns.instance, "cmd": "activate", "args": {"tabId": ns.tab_id}})
    elif ns.cmd == "rename":
        api_call(ns.port, "POST", "/api/exec",
                 {"instance": ns.instance, "cmd": "rename", "args": {"tabId": ns.tab_id, "name": " ".join(ns.name)}})
    elif ns.cmd == "startup":
        startup(ns.action)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
