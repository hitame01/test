const $ = s => document.querySelector(s);
let selfItems = [];   // このプロファイルのタブ
let otherItems = [];  // 他プロファイルのタブ
let items = [];
let view = [];
let selKey = null;    // 選択は行番号ではなくタブで覚える（並び替えでずれないように）
let editing = false;
let currentTabId = null;
let myInstance = null;
let warning = "";

const keyOf = it => it.instance + ":" + it.tab.id;

async function bg(msg) {
  const r = await chrome.runtime.sendMessage(msg);
  if (!r || !r.ok) throw new Error(r?.error || "background error");
  return r.data;
}

function norm(s) { return (s || "").normalize("NFKC").toLowerCase(); }

function color(label) {
  let h = 0;
  for (const c of label) h = (h * 31 + c.codePointAt(0)) >>> 0;
  return `hsl(${h % 360} 55% 42%)`;
}

function hostOf(url) {
  try { const u = new URL(url); return u.host + u.pathname; } catch { return url; }
}

function isCurrent(it) { return it.self && it.tab.id === currentTabId; }

function rank0(it) {
  if (isCurrent(it)) return 3;
  if (it.tab.name) return 2;
  return it.self ? 1 : 0;
}

function selIndex() {
  const i = view.findIndex(it => keyOf(it) === selKey);
  return i < 0 ? 0 : i;
}

function filter({ resetSel = false } = {}) {
  items = [...selfItems, ...otherItems];
  const terms = norm($("#q").value).split(/\s+/).filter(Boolean);
  if (!terms.length) {
    // 空クエリ: 現在のタブ → 名前付きタブ → その他（同順位内は元の順）
    view = items.map((it, i) => ({ it, i })).sort((a, b) => rank0(b.it) - rank0(a.it) || a.i - b.i).map(x => x.it);
  } else {
    view = items
      .map(it => {
        const name = norm(it.tab.name), title = norm(it.tab.title);
        const hay = [name, title, norm(it.tab.url), norm(it.label)].join("\n");
        if (!terms.every(t => hay.includes(t))) return null;
        const score = terms.reduce((s, t) => s + (name.includes(t) ? 10 : 0) + (title.includes(t) ? 3 : 0), 0);
        return { it, score };
      })
      .filter(Boolean)
      .sort((a, b) => b.score - a.score)
      .map(x => x.it);
  }
  if (resetSel || !view.some(it => keyOf(it) === selKey)) selKey = view[0] ? keyOf(view[0]) : null;
  render();
}

function render() {
  const w = $("#warn");
  w.textContent = warning;
  w.hidden = !warning;

  const ul = $("#list");
  ul.replaceChildren();
  if (!view.length) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = items.length ? "一致するタブはありません" : "タブを読み込んでいます…";
    ul.append(li);
    return;
  }
  const sel = selIndex();
  view.forEach((it, i) => {
    const li = document.createElement("li");
    li.setAttribute("role", "option");
    if (i === sel) li.classList.add("sel");

    const fav = document.createElement("img");
    fav.className = "fav";
    fav.alt = "";
    if (it.tab.favIconUrl) fav.src = it.tab.favIconUrl; else fav.style.visibility = "hidden";
    fav.onerror = () => { fav.style.visibility = "hidden"; };

    const prof = document.createElement("span");
    prof.className = "prof";
    prof.textContent = it.label;
    prof.style.background = color(it.label);

    const main = document.createElement("div");
    main.className = "main";
    const l1 = document.createElement("div");
    l1.className = "line1";
    if (it.tab.name) {
      const n = document.createElement("span");
      n.className = "name";
      n.textContent = it.tab.name;
      l1.append(n);
    }
    l1.append(document.createTextNode(it.tab.title || "(無題)"));
    const l2 = document.createElement("div");
    l2.className = "line2";
    l2.textContent = hostOf(it.tab.url);
    main.append(l1, l2);

    const cur = document.createElement("span");
    cur.className = "cur";
    cur.textContent = isCurrent(it) ? "現在のタブ" : "";

    li.append(fav, prof, main, cur);
    li.addEventListener("click", () => { selKey = keyOf(it); activate(); });
    ul.append(li);
  });
  ul.children[sel]?.scrollIntoView({ block: "nearest" });
}

function moveSel(delta) {
  if (!view.length) return;
  const i = Math.max(0, Math.min(view.length - 1, selIndex() + delta));
  selKey = keyOf(view[i]);
  render();
}

async function activate() {
  const it = view[selIndex()];
  if (!it) return;
  try {
    await bg({ op: "exec", instance: it.instance, cmd: "activate", args: { tabId: it.tab.id } });
    window.close();
  } catch (e) { warning = "移動できませんでした: " + e.message; render(); }
}

function startRename(target) {
  const it = target || view[selIndex()];
  if (!it) return;
  selKey = keyOf(it);
  render();
  const li = $("#list").children[selIndex()];
  if (!li) return;
  editing = true;
  const main = li.querySelector(".main");
  const input = document.createElement("input");
  input.className = "edit";
  input.value = it.tab.name;
  input.placeholder = "名前（空にすると解除）";
  main.replaceChildren(input);
  input.focus();
  input.select();

  const finish = () => { editing = false; filter(); $("#q").focus(); };
  input.addEventListener("keydown", async e => {
    e.stopPropagation();
    if (e.isComposing) return;   // IME変換中の Enter/Esc は無視
    if (e.key === "Escape") { e.preventDefault(); finish(); }
    if (e.key === "Enter") {
      e.preventDefault();
      const name = input.value.trim();
      try {
        await bg({ op: "exec", instance: it.instance, cmd: "rename", args: { tabId: it.tab.id, name } });
        it.tab.name = name;   // 楽観的に反映（他プロファイル側は非同期で確定）
        // 開いてすぐ名付けした場合はそのまま閉じる。検索してから名付けた場合は一覧に戻る
        if (closeAfterRename) { window.close(); return; }
      } catch (err) { warning = "名前を付けられませんでした: " + err.message; }
      finish();
    }
  });
  input.addEventListener("blur", () => { if (editing) finish(); });
}

let closeAfterRename = false;

document.addEventListener("keydown", e => {
  if (editing || e.isComposing) return;
  if (e.key === "ArrowDown") { e.preventDefault(); moveSel(1); }
  else if (e.key === "ArrowUp") { e.preventDefault(); moveSel(-1); }
  else if (e.key === "Enter" && document.activeElement === $("#q")) { e.preventDefault(); activate(); }
  else if (e.key === "F2") {
    e.preventDefault();
    // 検索欄が空で現在のタブを選んでいる＝「開いてすぐリネーム」の操作
    closeAfterRename = !$("#q").value && view[selIndex()] && isCurrent(view[selIndex()]);
    startRename();
  }
  else if (e.key === "Escape") { window.close(); }
});
$("#q").addEventListener("input", () => filter({ resetSel: true }));

$("#label").addEventListener("change", async e => {
  await bg({ op: "setLabel", label: e.target.value });
  const me = await bg({ op: "listSelf" });
  selfItems.forEach(it => { it.label = me.label; });
  filter();
});

function toItems(ins, self) {
  return ins.tabs.map(tab => ({ instance: ins.instance, label: ins.label, self, tab }));
}

async function load() {
  const [cur] = await chrome.tabs.query({ active: true, currentWindow: true });
  currentTabId = cur?.id ?? null;

  // 1) 自分のプロファイルを即表示（デーモンを待たない）
  try {
    const me = await bg({ op: "listSelf" });
    myInstance = me.instance;
    $("#label").value = me.label;
    selfItems = toItems(me, true);
  } catch (e) {
    warning = "タブ一覧を取得できませんでした: " + e.message;
  }
  filter({ resetSel: true });

  // ショートカット(Alt+Shift+N)で開かれた場合は、現在のタブのリネームから始める
  if (await bg({ op: "takeRenameFlag" }).catch(() => false)) {
    const curItem = selfItems.find(isCurrent);
    if (curItem) { closeAfterRename = true; startRename(curItem); }
  }

  // 2) 他プロファイルを後から合流させる（選択と編集中の入力は維持）
  try {
    const { instances, warning: w } = await bg({ op: "listOthers" });
    warning = w || "";
    otherItems = instances.flatMap(ins => toItems(ins, false));
  } catch (e) {
    warning = "他のプロファイルのタブを取得できませんでした: " + e.message;
  }
  if (editing) {
    const w = $("#warn"); w.textContent = warning; w.hidden = !warning;
    items = [...selfItems, ...otherItems];   // 編集が終わったら finish() で再描画される
  } else {
    filter();
  }
}

load();
