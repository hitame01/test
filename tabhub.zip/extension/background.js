// TabHub background service worker
// 各プロファイルにインストールされ、ローカルのデーモン(tabhub_daemon.py)に WebSocket で接続する。
const DAEMON_PORT = 47821;   // デーモンを --port で変えた場合はここも合わせる
const DAEMON_URL = `ws://127.0.0.1:${DAEMON_PORT}/ws`;
const MAX_URL = 1000, MAX_TITLE = 300;
const KEEPALIVE_MS = 20000;  // 30秒未満で通信して Service Worker の停止を防ぐ (Chrome 116+)

let ws = null;
let ready = false;
let readyWaiters = [];
let seq = 0;
const pending = new Map();
let pushTimer = null;
let retryTimer = null;
let retryMs = 2000;

// ---------- storage ----------
async function getIdentity() {
  let { instance, label } = await chrome.storage.local.get(["instance", "label"]);
  if (!instance) {
    instance = crypto.randomUUID();
    label = label || "profile-" + instance.slice(0, 4);
    await chrome.storage.local.set({ instance, label });
  }
  return { instance, label: label || "profile-" + instance.slice(0, 4) };
}
async function getNames() {
  return (await chrome.storage.session.get("names")).names || {};
}
async function setName(tabId, name) {
  const names = await getNames();
  name = (name || "").trim();
  if (name) names[tabId] = name; else delete names[tabId];
  await chrome.storage.session.set({ names });
  schedulePush();
}

// ---------- tabs ----------
async function collectTabs() {
  const [tabs, names] = await Promise.all([chrome.tabs.query({}), getNames()]);
  return tabs.map(t => ({
    id: t.id,
    windowId: t.windowId,
    index: t.index,
    active: t.active,
    pinned: t.pinned,
    title: (t.title || "").slice(0, MAX_TITLE),
    url: (t.url || t.pendingUrl || "").slice(0, MAX_URL),
    favIconUrl: t.favIconUrl && /^https?:/.test(t.favIconUrl) && t.favIconUrl.length < 500 ? t.favIconUrl : "",
    name: names[t.id] || ""
  }));
}

async function runLocal(cmd, args = {}) {
  if (cmd === "activate") {
    const tab = await chrome.tabs.update(args.tabId, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
  } else if (cmd === "rename") {
    await setName(args.tabId, args.name);
  } else {
    throw new Error("unknown command: " + cmd);
  }
}

// ---------- daemon connection ----------
function send(msg) {
  const s = ws;
  if (!s || s.readyState !== WebSocket.OPEN) return false;
  try { s.send(JSON.stringify(msg)); return true; }
  catch (e) { console.warn("TabHub: send failed:", e.message); return false; }
}

function setReady(v) {
  ready = v;
  if (v) { readyWaiters.forEach(r => r()); readyWaiters = []; }
}
function waitReady(ms) {
  if (ready) return Promise.resolve();
  return new Promise(resolve => {
    readyWaiters.push(resolve);
    setTimeout(resolve, ms);
  });
}

function scheduleReconnect() {
  clearTimeout(retryTimer);
  retryTimer = setTimeout(connect, retryMs);
  retryMs = Math.min(retryMs * 2, 30000);
}

function connect() {
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) return;
  clearTimeout(retryTimer);
  let s;
  try { s = new WebSocket(DAEMON_URL); }
  catch (e) { scheduleReconnect(); return; }
  ws = s;
  s.onopen = async () => {
    const { instance, label } = await getIdentity();
    send({ type: "hello", instance, label });
  };
  s.onmessage = e => {
    let msg;
    try { msg = JSON.parse(e.data); } catch { return; }
    onDaemonMessage(msg);
  };
  s.onerror = () => {};          // 直後に onclose が来るのでそちらで処理する
  s.onclose = () => {
    if (ws !== s) return;
    ws = null;
    setReady(false);
    for (const p of pending.values()) p.reject(new Error("デーモンとの接続が切れました"));
    pending.clear();
    scheduleReconnect();
  };
}

async function onDaemonMessage(msg) {
  if (msg.type === "ready") {
    retryMs = 2000;
    setReady(true);
    schedulePush(0);
  } else if (msg.type === "response") {
    const p = pending.get(msg.id);
    if (!p) return;
    pending.delete(msg.id);
    msg.ok ? p.resolve(msg.data) : p.reject(new Error(msg.error || "daemon error"));
  } else if (msg.type === "command") {
    try { await runLocal(msg.cmd, msg.args); }
    catch (e) { console.warn("TabHub: command failed", msg, e); }
  }
}

function schedulePush(delay = 300) {
  clearTimeout(pushTimer);
  pushTimer = setTimeout(async () => {
    if (!ready) return;
    const { label } = await getIdentity();
    const tabs = await collectTabs();
    send({ type: "tabs", label, tabs });
  }, delay);
}

function daemonRequest(cmd, args = {}, timeout = 3000) {
  return new Promise((resolve, reject) => {
    const id = ++seq;
    const timer = setTimeout(() => { pending.delete(id); reject(new Error("デーモンが応答しません")); }, timeout);
    pending.set(id, {
      resolve: v => { clearTimeout(timer); resolve(v); },
      reject: e => { clearTimeout(timer); reject(e); }
    });
    if (!ready || !send({ type: "request", id, cmd, ...args })) {
      pending.get(id)?.reject(new Error("デーモンに接続していません"));
      pending.delete(id);
    }
  });
}

setInterval(() => send({ type: "ping" }), KEEPALIVE_MS);

// Service Worker が停止した後もデーモンへの再接続を試みる
chrome.alarms.create("tabhub-reconnect", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(a => { if (a.name === "tabhub-reconnect") connect(); });

connect();

// ---------- tab events ----------
chrome.tabs.onCreated.addListener(() => schedulePush());
chrome.tabs.onRemoved.addListener(async tabId => {
  const names = await getNames();
  if (names[tabId]) { delete names[tabId]; await chrome.storage.session.set({ names }); }
  schedulePush();
});
chrome.tabs.onUpdated.addListener((_id, info) => {
  if ("title" in info || "url" in info || "pinned" in info) schedulePush();
});
chrome.tabs.onActivated.addListener(() => schedulePush());
chrome.tabs.onMoved.addListener(() => schedulePush());
chrome.tabs.onAttached.addListener(() => schedulePush());
chrome.tabs.onDetached.addListener(() => schedulePush());
chrome.tabs.onReplaced.addListener(async (added, removed) => {
  const names = await getNames();
  if (names[removed]) { names[added] = names[removed]; delete names[removed]; await chrome.storage.session.set({ names }); }
  schedulePush();
});

// ---------- popup API ----------
async function handlePopup(msg) {
  const me = await getIdentity();
  switch (msg.op) {
    case "listSelf":
      // デーモンを待たずに即返す（ポップアップを開いてすぐ F2 できるように）
      return { ...me, self: true, tabs: await collectTabs() };
    case "listOthers": {
      connect();
      await waitReady(1500);
      if (!ready) {
        return { instances: [], warning: "TabHub デーモンに接続できないため、このプロファイルのタブだけを表示しています。tabhub_daemon.py を起動してください。" };
      }
      try {
        return { instances: await daemonRequest("list_others") };
      } catch (e) {
        return { instances: [], warning: "他のプロファイルのタブを取得できませんでした: " + e.message };
      }
    }
    case "exec":
      if (msg.instance === me.instance) await runLocal(msg.cmd, msg.args);
      else await daemonRequest("remote", { target: msg.instance, ext_cmd: msg.cmd, args: msg.args });
      return null;
    case "takeRenameFlag": {
      const { renameOnOpen } = await chrome.storage.session.get("renameOnOpen");
      await chrome.storage.session.remove("renameOnOpen");
      return !!renameOnOpen && Date.now() - renameOnOpen < 5000;
    }
    case "setLabel": {
      await chrome.storage.local.set({ label: (msg.label || "").trim() || me.label });
      schedulePush(0);
      return null;
    }
    default:
      throw new Error("unknown op: " + msg.op);
  }
}

// 「現在のタブに名前を付ける」ショートカット: ポップアップをリネーム状態で開く
chrome.commands.onCommand.addListener(async command => {
  if (command !== "rename-current") return;
  await chrome.storage.session.set({ renameOnOpen: Date.now() });
  try {
    await chrome.action.openPopup();
  } catch (e) {
    console.warn("TabHub: openPopup failed:", e.message);
    await chrome.storage.session.remove("renameOnOpen");
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  handlePopup(msg).then(
    data => sendResponse({ ok: true, data }),
    e => sendResponse({ ok: false, error: String(e?.message || e) })
  );
  return true;
});
