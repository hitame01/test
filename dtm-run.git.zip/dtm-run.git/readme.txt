● 準備完了

  D:\Studio\dtm-run.git.zip(約68KB)を作成しました。中身は履歴を含む bare リポジトリで、git subtree add/pull が正しく通ることを実際に模擬環境で検証済みです。

  先方PCでの手順

  ① ZIPを展開(先方の既存リポジトリの外、作業用の場所でOK)
  例: C:\tools\dtm-run.git.zip を展開 → C:\tools\dtm-run.git

  ② 既存リポジトリのルートで subtree 取り込み
  cd <既存リポジトリのルート>
  git remote add dtm-run "C:\tools\dtm-run.git"
  git subtree add --prefix=tools/dtm-run dtm-run master --squash
  → host/ src/ cli.js package.json .vscode/ などが履歴付きで tools/dtm-run/ 配下にまとまります。

  ③ 依存関係のインストール
  cd tools/dtm-run
  npm install

  ④ .vscode/launch.json などを既存リポジトリのルートにマージ
  tools/dtm-run/.vscode/*.json は VSCode がワークスペースルートの .vscode/ しか見ないため、そのままでは効きません。既存リポジトリのルートに .vscode/launch.json
  等が無ければ丸ごとコピー、既にあれば中身をマージしてください。パスを tools/dtm-run/ 付きに直す必要があります:

  // .vscode/launch.json（ルート側）に追記する例
  {
    "type": "node",
    "request": "launch",
    "name": "DTM: 開いているファイルを実行",
    "program": "${workspaceFolder}/tools/dtm-run/cli.js",
    "args": ["${file}", "--host", "${workspaceFolder}/tools/dtm-run/host"],
    "cwd": "${workspaceFolder}",
    "console": "integratedTerminal"
  }
  tasks.json・settings.json(code-runner の executorMap)も同様に tools/dtm-run/cli.js へパスを直してください。

  今後の更新

  このZIP方式はネットワーク接続なしのオフライン取り込みなので、更新のたびに 同じ手順を繰り返す運用になります。私の方でこのリポジトリに変更が入るたびに新しい ZIP を作りますので、それを展開し直して:
  git subtree pull --prefix=tools/dtm-run dtm-run master --squash
  を実行すれば差分だけ取り込まれます(実際に動作確認済みです)。

  ---なお D:\Studio\dtm-run.git.zip は本体リポジトリ(dtm-js-runnner)とは別の一時ファイルです。不要になれば削除して構いません。次に配布用ZIPを作り直すタイミングがあれば教えてください。

✻ Cogitated for 2m 6s

※ recap: We've been building the dtm-run tool and setting up VSCode. Right now I've packaged it as dtm-run.git.zip for a colleague to import via git subtree into their existing repo; next you'll copy that ZIP
  to their machine and run the import steps.