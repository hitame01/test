@echo off
setlocal
cd /d "%~dp0"

where py >nul 2>nul
if %ERRORLEVEL%==0 (
  set PY=py
) else (
  set PY=python
)

if not exist ".venv\Scripts\python.exe" (
  %PY% -m venv .venv
  if errorlevel 1 goto :error
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m pip install pyinstaller
if errorlevel 1 goto :error

pyinstaller --noconfirm --clean --onefile --windowed ^
  --name NotebookLMSplitter ^
  --collect-all fitz ^
  notebooklm_splitter.py
if errorlevel 1 goto :error

echo.
echo Build complete:
echo   dist\NotebookLMSplitter.exe
pause
goto :eof

:error
echo.
echo Build failed.
pause
exit /b 1
