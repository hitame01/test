# NotebookLM Splitter

PDF / DOCX を NotebookLM に読み込ませやすい大きさへ分割する小型ツールです。

## 何をするツールか

- **PDF**
  - 元PDFのページをそのまま切り出します。
  - レイアウト・図・表を再構成しません。
  - 抽出可能な本文を使って分割量を見積もります。
  - 画像PDFなど文字抽出できないページは、既定で **2,000 units/ページ** として安全寄りに見積もります。
- **DOCX**
  - 元DOCXを再生成せず、OOXMLパッケージを複製して不要な段落・表を除去します。
  - 見出し付近を優先して分割します。
  - スタイル、画像、番号付け、ヘッダー/フッター等をできるだけ保持します。
- **共通**
  - `manifest.csv` を出力します。
  - カウント上限とファイルサイズ上限を両方確認します。
  - 既定値は `350,000 estimated tokens / 180 MB` です。

## NotebookLM側の上限について

2026-08-16 時点のGoogle公式ヘルプでは、通常ソースは
**1ソースあたり最大500,000 words または200MB** とされています。
Google Sheets は別扱いで 100k tokens と案内されています。

このツールの `tokens` は **Gemini/NotebookLMの正確な内部トークナイザではありません**。
日本語文書の「word」境界も外部から厳密に再現しにくいため、
既定では安全寄りの「推定トークン数」を使います。

## Windowsで使う

### 一番簡単

1. Python 3.10以上をインストール
   - インストール時に `Add Python to PATH` を有効にする
2. このフォルダの `setup_and_run.bat` をダブルクリック
3. 初回だけ仮想環境と依存パッケージを作成します
4. GUIでPDF/DOCXを追加して `分割開始`

2回目以降は `run.bat` でも起動できます。

## EXEを作る

`build_exe.bat` をダブルクリックしてください。

成功すると:

```text
dist\NotebookLMSplitter.exe
```

が作られます。

## GUI設定

### カウント方式

- `tokens`
  - 推奨
  - Geminiの厳密なtoken数ではなく、混在言語向けの安全寄り概算
- `words`
  - 英数字は語単位
  - CJK（日本語・中国語・韓国語）は保守的に1文字=1単位
- `chars`
  - 文字数

### 1パート上限

既定: `350000`

NotebookLM側の500,000 wordsをぎりぎり狙わず余裕を持たせています。

### ファイル上限

既定: `180 MB`

NotebookLM公式の200MBより余裕を持たせています。

### 重複数

既定: `0`

- PDF: 前パート末尾のページを次パートにも何ページ含めるか
- DOCX: 前パート末尾の段落/表ブロックを次パートにも何ブロック含めるか

NotebookLMの引用・検索で同じ文章が重複する可能性があるため、通常は0推奨です。

## CLI

```bat
python notebooklm_splitter.py manual.pdf
```

複数ファイル:

```bat
python notebooklm_splitter.py a.pdf b.docx -o C:\work\split
```

上限変更:

```bat
python notebooklm_splitter.py a.pdf --mode tokens --max-units 300000 --max-mb 170
```

少量のオーバーラップ:

```bat
python notebooklm_splitter.py a.pdf --overlap 1
```

## 出力例

```text
NotebookLM_Split\
  manual_pdf_split\
    manual_part001.pdf
    manual_part002.pdf
    manual_part003.pdf
    manifest.csv
```

`manifest.csv` には各partの範囲、概算カウント、ファイルサイズ、警告が入ります。

## 注意点

1. **スキャンPDF**
   - OCRをこのツール自身では行いません。
   - 文字抽出できないページは固定unitsで見積もります。
2. **1ページだけで上限を超えるPDF**
   - ページを画像/レイアウトごと割らない設計なので、そのページは単独partとして警告されます。
3. **巨大な単一表・単一段落のDOCX**
   - 1ブロック自体が上限を超える場合は、それ以上内部分割せず警告します。
4. **Wordの特殊機能**
   - 埋め込みオブジェクト、マクロ、複雑なフィールド、変更履歴など特殊な文書は、
     分割後にWordで目視確認してください。
   - `.docm` は対象外です。
5. **パスワード付きPDF**
   - PyMuPDFで開けない場合は処理できません。

## 依存関係

- Python 3.10+
- PyMuPDF >= 1.24
- lxml >= 5

DOCX処理は `zipfile` と `lxml` を利用し、Word固有のXML名前空間を保持して分割します。

## ライセンス

MIT
