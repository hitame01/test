#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NotebookLM Splitter
- PDF: splits by page boundaries while preserving original pages.
- DOCX: splits by top-level paragraph/table blocks by editing OOXML directly.
- Supports approximate token / word / character counting.
- Writes manifest.csv for each input.

Python 3.10+
Dependency: PyMuPDF
"""

from __future__ import annotations

import argparse
import csv
import math
import os
import posixpath
import re
import shutil
import sys
import tempfile
import zipfile
from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Optional, Sequence, Tuple
import xml.etree.ElementTree as ET

APP_NAME = "NotebookLM Splitter"
APP_VERSION = "1.0.0"

# OOXML namespaces
W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PKG_REL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
NS = {"w": W_NS, "r": R_NS}
W = "{" + W_NS + "}"
R = "{" + R_NS + "}"
PKGREL = "{" + PKG_REL_NS + "}"

DEFAULT_MAX_UNITS = 350_000
DEFAULT_MAX_MB = 180.0
DEFAULT_EMPTY_PDF_PAGE_UNITS = 2_000
DEFAULT_MIN_HEADING_RATIO = 0.62

CJK_RE = re.compile(
    r"[\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff"
    r"\uf900-\ufaff\uac00-\ud7af]"
)
LATIN_WORD_RE = re.compile(r"[A-Za-z0-9_]+(?:['’-][A-Za-z0-9_]+)*")
NONSPACE_RE = re.compile(r"\S")


def human_mb(n: int) -> float:
    return n / (1024 * 1024)


def count_words(text: str) -> int:
    """
    Approximate 'word' count for mixed-language documents.
    Latin-like text is counted by word; each CJK character is counted as 1
    conservative unit because Japanese/Chinese word boundaries are ambiguous.
    """
    if not text:
        return 0
    latin = len(LATIN_WORD_RE.findall(text))
    cjk = len(CJK_RE.findall(text))
    # Other non-space symbols are not treated as full words.
    return latin + cjk


def estimate_tokens(text: str) -> int:
    """
    Conservative rough token estimate, NOT Gemini's exact tokenizer.
    Heuristic:
      - Latin-ish word: ~1.35 tokens
      - CJK character: ~1 token
      - remaining non-space punctuation/symbols: ~0.35 token
    """
    if not text:
        return 0
    latin_words = len(LATIN_WORD_RE.findall(text))
    cjk_chars = len(CJK_RE.findall(text))

    # Remove recognized Latin/CJK content and count remaining visible symbols.
    tmp = LATIN_WORD_RE.sub("", text)
    tmp = CJK_RE.sub("", tmp)
    other = len(NONSPACE_RE.findall(tmp))

    return int(math.ceil(latin_words * 1.35 + cjk_chars * 1.0 + other * 0.35))


def count_units(text: str, mode: str) -> int:
    if mode == "tokens":
        return estimate_tokens(text)
    if mode == "words":
        return count_words(text)
    if mode == "chars":
        return len(text)
    raise ValueError(f"Unknown count mode: {mode}")


@dataclass
class PartRecord:
    filename: str
    source_type: str
    start: str
    end: str
    units: int
    unit_mode: str
    size_mb: float
    note: str = ""


def write_manifest(out_dir: Path, records: Sequence[PartRecord]) -> Path:
    path = out_dir / "manifest.csv"
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow([
            "filename", "source_type", "start", "end",
            "count", "count_mode", "size_mb", "note"
        ])
        for r in records:
            w.writerow([
                r.filename, r.source_type, r.start, r.end,
                r.units, r.unit_mode, f"{r.size_mb:.2f}", r.note
            ])
    return path


# ---------------------------------------------------------------------------
# PDF
# ---------------------------------------------------------------------------

def _pdf_ranges(
    page_units: Sequence[int],
    max_units: int,
    overlap_pages: int,
) -> List[Tuple[int, int]]:
    """Returns zero-based inclusive page ranges."""
    n = len(page_units)
    ranges: List[Tuple[int, int]] = []
    start = 0

    while start < n:
        total = 0
        end = start

        while end < n:
            u = page_units[end]
            if end > start and total + u > max_units:
                break
            total += u
            end += 1
            if total >= max_units:
                break

        # Guarantee progress even if a single page itself exceeds the threshold.
        if end == start:
            end = start + 1

        ranges.append((start, end - 1))
        if end >= n:
            break

        next_start = max(start + 1, end - max(0, overlap_pages))
        start = next_start

    return ranges


def _save_pdf_range(src_doc, start: int, end: int, out_path: Path) -> None:
    import fitz  # PyMuPDF
    new = fitz.open()
    new.insert_pdf(src_doc, from_page=start, to_page=end)
    try:
        meta = src_doc.metadata or {}
        if meta:
            new.set_metadata(meta)
    except Exception:
        pass
    # garbage=4 removes unused objects; deflate helps image/text streams where possible.
    new.save(str(out_path), garbage=4, deflate=True)
    new.close()


def _split_pdf_range_by_size(
    src_doc,
    start: int,
    end: int,
    out_dir: Path,
    stem: str,
    max_bytes: int,
    temp_counter: List[int],
) -> List[Tuple[int, int, Path]]:
    """
    Materialize a range. If it exceeds max_bytes and has >1 page,
    recursively split it in half.
    """
    temp_counter[0] += 1
    temp_path = out_dir / f".__tmp_{temp_counter[0]:05d}.pdf"
    _save_pdf_range(src_doc, start, end, temp_path)

    if temp_path.stat().st_size <= max_bytes or start == end:
        return [(start, end, temp_path)]

    temp_path.unlink(missing_ok=True)
    mid = (start + end) // 2
    left = _split_pdf_range_by_size(
        src_doc, start, mid, out_dir, stem, max_bytes, temp_counter
    )
    right = _split_pdf_range_by_size(
        src_doc, mid + 1, end, out_dir, stem, max_bytes, temp_counter
    )
    return left + right


def split_pdf(
    src: Path,
    out_dir: Path,
    max_units: int,
    unit_mode: str,
    max_mb: float,
    overlap_pages: int,
    empty_page_units: int,
) -> List[PartRecord]:
    import fitz  # PyMuPDF

    doc = fitz.open(str(src))
    try:
        if doc.page_count == 0:
            raise ValueError("PDF has no pages.")

        page_texts = []
        page_units = []
        empty_pages = 0
        for i in range(doc.page_count):
            text = doc.load_page(i).get_text("text") or ""
            page_texts.append(text)
            u = count_units(text, unit_mode)
            if not text.strip():
                empty_pages += 1
                u = max(u, empty_page_units)
            page_units.append(u)

        ranges = _pdf_ranges(page_units, max_units, overlap_pages)
        max_bytes = int(max_mb * 1024 * 1024)
        temp_counter = [0]

        # Enforce file-size ceiling too.
        materialized: List[Tuple[int, int, Path]] = []
        for start, end in ranges:
            materialized.extend(
                _split_pdf_range_by_size(
                    doc, start, end, out_dir, src.stem, max_bytes, temp_counter
                )
            )

        records: List[PartRecord] = []
        for idx, (start, end, tmp_path) in enumerate(materialized, 1):
            final = out_dir / f"{src.stem}_part{idx:03d}.pdf"
            if final.exists():
                final.unlink()
            tmp_path.replace(final)

            # Recalculate from source page estimates.
            units = sum(page_units[start:end + 1])
            notes = []
            if start == end and units > max_units:
                notes.append("single page exceeds count threshold")
            if final.stat().st_size > max_bytes:
                notes.append("single-page/file content exceeds size threshold")
            if empty_pages:
                notes.append(
                    f"{empty_pages} page(s) had no extractable text; "
                    f"{empty_page_units} units/page fallback used"
                )

            records.append(PartRecord(
                filename=final.name,
                source_type="PDF",
                start=f"page {start + 1}",
                end=f"page {end + 1}",
                units=units,
                unit_mode=unit_mode,
                size_mb=human_mb(final.stat().st_size),
                note="; ".join(notes),
            ))
        return records
    finally:
        doc.close()


# ---------------------------------------------------------------------------
# DOCX
# ---------------------------------------------------------------------------

def _zip_read(z: zipfile.ZipFile, name: str) -> Optional[bytes]:
    try:
        return z.read(name)
    except KeyError:
        return None


def _docx_style_info(z: zipfile.ZipFile) -> dict:
    """
    style_id -> {name, outline}
    """
    raw = _zip_read(z, "word/styles.xml")
    if not raw:
        return {}
    root = ET.fromstring(raw)
    out = {}
    for style in root.findall("w:style", NS):
        sid = style.get(W + "styleId", "")
        name_el = style.find("w:name", NS)
        name = name_el.get(W + "val", "") if name_el is not None else ""
        outline = None

        ppr = style.find("w:pPr", NS)
        if ppr is not None:
            ol = ppr.find("w:outlineLvl", NS)
            if ol is not None:
                try:
                    outline = int(ol.get(W + "val"))
                except Exception:
                    outline = None

        out[sid] = {"name": name, "outline": outline}
    return out


def _block_text(el: ET.Element) -> str:
    texts = []
    for t in el.iter(W + "t"):
        if t.text:
            texts.append(t.text)
    return "".join(texts)


def _paragraph_style_id(p: ET.Element) -> str:
    ppr = p.find("w:pPr", NS)
    if ppr is None:
        return ""
    ps = ppr.find("w:pStyle", NS)
    if ps is None:
        return ""
    return ps.get(W + "val", "") or ""


def _is_heading_block(el: ET.Element, style_info: dict) -> bool:
    if el.tag != W + "p":
        return False
    sid = _paragraph_style_id(el)
    info = style_info.get(sid, {})
    name = (info.get("name") or sid or "").strip().lower()
    outline = info.get("outline")

    if outline is not None and 0 <= outline <= 8:
        return True
    if name.startswith("heading") or name.startswith("見出し"):
        return True
    if name in {"title", "subtitle", "タイトル"}:
        return True
    return False


def _chunk_docx_blocks(
    block_units: Sequence[int],
    headings: Sequence[bool],
    max_units: int,
    overlap_blocks: int,
    min_heading_ratio: float = DEFAULT_MIN_HEADING_RATIO,
) -> List[Tuple[int, int]]:
    n = len(block_units)
    ranges: List[Tuple[int, int]] = []
    start = 0

    while start < n:
        total = 0
        end = start
        last_good_heading = None

        while end < n:
            u = block_units[end]

            # A heading is a natural boundary BEFORE itself.
            if (
                headings[end]
                and end > start
                and total >= max_units * min_heading_ratio
            ):
                last_good_heading = end

            if end > start and total + u > max_units:
                break

            total += u
            end += 1

            if total >= max_units:
                break

        if end == start:
            end = start + 1

        # If we hit/exceeded the threshold, prefer a recent heading boundary.
        if end < n and last_good_heading is not None and last_good_heading > start:
            end = last_good_heading

        ranges.append((start, end - 1))
        if end >= n:
            break

        start = max(start + 1, end - max(0, overlap_blocks))

    return ranges


def _relationship_ids_used(root: ET.Element) -> set:
    ids = set()
    for el in root.iter():
        for attr_name, value in el.attrib.items():
            if attr_name.startswith("{" + R_NS + "}") and value:
                ids.add(value)
    return ids


def _rels_owner_from_path(rels_path: str) -> Optional[str]:
    # e.g. word/_rels/header1.xml.rels -> word/header1.xml
    p = Path(rels_path)
    if p.parent.name != "_rels" or not p.name.endswith(".rels"):
        return None
    owner_name = p.name[:-5]
    return str(p.parent.parent / owner_name).replace("\\", "/")


def _normalize_part_target(owner_part: str, target: str) -> Optional[str]:
    if not target or "://" in target or target.startswith("#"):
        return None
    base = posixpath.dirname(owner_part)
    return posixpath.normpath(posixpath.join(base, target))


def _all_other_referenced_parts(
    src_zip: zipfile.ZipFile,
    excluding_rels_path: str,
) -> set:
    refs = set()
    for name in src_zip.namelist():
        if not name.endswith(".rels") or name == excluding_rels_path:
            continue
        raw = _zip_read(src_zip, name)
        if not raw:
            continue
        try:
            root = ET.fromstring(raw)
        except Exception:
            continue
        owner = _rels_owner_from_path(name)
        if not owner:
            continue
        for rel in root.findall(PKGREL + "Relationship"):
            if rel.get("TargetMode") == "External":
                continue
            target = _normalize_part_target(owner, rel.get("Target", ""))
            if target:
                refs.add(target)
    return refs


def _build_docx_chunk(
    src: Path,
    out_path: Path,
    start_block: int,
    end_block: int,
) -> None:
    """
    Copy the DOCX package and remove top-level body paragraphs/tables outside
    [start_block, end_block]. This preserves styles, numbering, media, headers,
    footers, etc. It also prunes document-level image/embed parts no longer used.
    """
    from lxml import etree as LET

    with zipfile.ZipFile(src, "r") as zin:
        doc_raw = zin.read("word/document.xml")
        # lxml preserves the original namespace map. This is important for
        # mc:Ignorable values such as "w14 wp14" used by Word documents.
        root = LET.fromstring(doc_raw)
        body = root.find("w:body", NS)
        if body is None:
            raise ValueError("Invalid DOCX: word/document.xml has no body")

        # Treat every top-level body child except the final sectPr as a block.
        # This also handles content controls (w:sdt), altChunk, customXml, etc.
        all_blocks = [child for child in list(body) if child.tag != W + "sectPr"]
        final_body_sectpr = body.find("w:sectPr", NS)

        # Find the section properties that apply at the end of this chunk.
        # For intermediate Word sections, sectPr lives in the paragraph that
        # closes the section. If the cut happens before that paragraph, use the
        # next sectPr; otherwise fall back to the document's final sectPr.
        effective_sectpr = None
        effective_source_block = None
        for i in range(end_block, len(all_blocks)):
            child = all_blocks[i]
            if child.tag == W + "p":
                sp = child.find("w:pPr/w:sectPr", NS)
                if sp is not None:
                    effective_sectpr = deepcopy(sp)
                    effective_source_block = i
                    break
        if effective_sectpr is None and final_body_sectpr is not None:
            effective_sectpr = deepcopy(final_body_sectpr)

        # Remove blocks outside the selected range.
        for i, child in enumerate(list(all_blocks)):
            if not (start_block <= i <= end_block):
                body.remove(child)

        # If the selected last block itself contains the sectPr we just promoted,
        # remove that paragraph-level section break to avoid an empty trailing
        # section, then install it as the final body sectPr.
        if effective_source_block == end_block and 0 <= end_block < len(all_blocks):
            last_child = all_blocks[end_block]
            if last_child.tag == W + "p":
                ppr = last_child.find("w:pPr", NS)
                if ppr is not None:
                    sp = ppr.find("w:sectPr", NS)
                    if sp is not None:
                        ppr.remove(sp)

        existing_final = body.find("w:sectPr", NS)
        if existing_final is not None:
            body.remove(existing_final)
        if effective_sectpr is not None:
            body.append(effective_sectpr)

        modified_doc = LET.tostring(
            root, encoding="UTF-8", xml_declaration=True, standalone=True
        )

        rels_path = "word/_rels/document.xml.rels"
        rels_raw = _zip_read(zin, rels_path)
        modified_rels = rels_raw
        remove_parts = set()

        # Prune unused document-level images/embedded packages to keep chunks small.
        if rels_raw:
            rels_root = LET.fromstring(rels_raw)
            used_ids = _relationship_ids_used(root)
            owner = "word/document.xml"
            other_refs = _all_other_referenced_parts(zin, rels_path)

            removable_type_suffixes = (
                "/image", "/oleObject", "/package"
            )

            for rel in list(rels_root.findall(PKGREL + "Relationship")):
                rid = rel.get("Id", "")
                rtype = rel.get("Type", "")
                if rid in used_ids:
                    continue
                if not rtype.endswith(removable_type_suffixes):
                    continue
                if rel.get("TargetMode") == "External":
                    rels_root.remove(rel)
                    continue

                target = _normalize_part_target(owner, rel.get("Target", ""))
                rels_root.remove(rel)
                if target and target not in other_refs:
                    remove_parts.add(target)

            modified_rels = LET.tostring(
                rels_root, encoding="UTF-8", xml_declaration=True, standalone=True
            )

        with zipfile.ZipFile(
            out_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6
        ) as zout:
            for info in zin.infolist():
                name = info.filename
                if name == "word/document.xml":
                    zout.writestr(info, modified_doc)
                elif name == rels_path and modified_rels is not None:
                    zout.writestr(info, modified_rels)
                elif name in remove_parts:
                    continue
                else:
                    zout.writestr(info, zin.read(name))


def _docx_blocks_and_units(
    src: Path,
    unit_mode: str,
) -> Tuple[List[ET.Element], List[int], List[bool], int]:
    with zipfile.ZipFile(src, "r") as z:
        doc_raw = z.read("word/document.xml")
        root = ET.fromstring(doc_raw)
        body = root.find("w:body", NS)
        if body is None:
            raise ValueError("Invalid DOCX: no document body")
        style_info = _docx_style_info(z)

        # Count all top-level body content except the final section-properties
        # element. This prevents top-level content controls from being duplicated
        # into every output chunk.
        blocks = [
            child for child in list(body)
            if child.tag != W + "sectPr"
        ]
        units = [count_units(_block_text(b), unit_mode) for b in blocks]
        headings = [_is_heading_block(b, style_info) for b in blocks]
        return blocks, units, headings, sum(units)


def _split_docx_range_by_size(
    src: Path,
    start: int,
    end: int,
    out_dir: Path,
    max_bytes: int,
    temp_counter: List[int],
) -> List[Tuple[int, int, Path]]:
    temp_counter[0] += 1
    temp_path = out_dir / f".__tmp_{temp_counter[0]:05d}.docx"
    _build_docx_chunk(src, temp_path, start, end)

    if temp_path.stat().st_size <= max_bytes or start == end:
        return [(start, end, temp_path)]

    temp_path.unlink(missing_ok=True)
    mid = (start + end) // 2
    left = _split_docx_range_by_size(
        src, start, mid, out_dir, max_bytes, temp_counter
    )
    right = _split_docx_range_by_size(
        src, mid + 1, end, out_dir, max_bytes, temp_counter
    )
    return left + right


def split_docx(
    src: Path,
    out_dir: Path,
    max_units: int,
    unit_mode: str,
    max_mb: float,
    overlap_blocks: int,
) -> List[PartRecord]:
    blocks, block_units, headings, _ = _docx_blocks_and_units(src, unit_mode)

    if not blocks:
        raise ValueError("DOCX has no body content to split.")

    ranges = _chunk_docx_blocks(
        block_units, headings, max_units, overlap_blocks
    )
    max_bytes = int(max_mb * 1024 * 1024)
    temp_counter = [0]

    materialized: List[Tuple[int, int, Path]] = []
    for start, end in ranges:
        materialized.extend(
            _split_docx_range_by_size(
                src, start, end, out_dir, max_bytes, temp_counter
            )
        )

    records: List[PartRecord] = []
    for idx, (start, end, tmp_path) in enumerate(materialized, 1):
        final = out_dir / f"{src.stem}_part{idx:03d}.docx"
        if final.exists():
            final.unlink()
        tmp_path.replace(final)

        units = sum(block_units[start:end + 1])
        notes = []
        if start == end and units > max_units:
            tag = blocks[start].tag
            if tag == W + "tbl":
                kind = "table"
            elif tag == W + "p":
                kind = "paragraph"
            else:
                kind = "body block"
            notes.append(f"single {kind} exceeds count threshold")
        if final.stat().st_size > max_bytes:
            notes.append("single block/package content exceeds size threshold")

        records.append(PartRecord(
            filename=final.name,
            source_type="DOCX",
            start=f"block {start + 1}",
            end=f"block {end + 1}",
            units=units,
            unit_mode=unit_mode,
            size_mb=human_mb(final.stat().st_size),
            note="; ".join(notes),
        ))
    return records


# ---------------------------------------------------------------------------
# Common processing
# ---------------------------------------------------------------------------

def clean_output_dir(out_dir: Path, stem: str, suffix: str) -> None:
    for p in out_dir.glob(f"{stem}_part*.{suffix}"):
        p.unlink(missing_ok=True)
    for p in out_dir.glob(".__tmp_*"):
        p.unlink(missing_ok=True)


def process_file(
    src: Path,
    parent_output: Path,
    max_units: int = DEFAULT_MAX_UNITS,
    unit_mode: str = "tokens",
    max_mb: float = DEFAULT_MAX_MB,
    overlap: int = 0,
    empty_pdf_page_units: int = DEFAULT_EMPTY_PDF_PAGE_UNITS,
) -> Tuple[Path, List[PartRecord]]:
    src = src.resolve()
    if not src.exists():
        raise FileNotFoundError(src)
    if src.suffix.lower() not in {".pdf", ".docx"}:
        raise ValueError(f"Unsupported file type: {src.suffix}")

    out_dir = parent_output / f"{src.stem}_{src.suffix.lower().lstrip(chr(46))}_split"
    out_dir.mkdir(parents=True, exist_ok=True)
    clean_output_dir(out_dir, src.stem, src.suffix.lower().lstrip("."))

    if src.suffix.lower() == ".pdf":
        records = split_pdf(
            src=src,
            out_dir=out_dir,
            max_units=max_units,
            unit_mode=unit_mode,
            max_mb=max_mb,
            overlap_pages=overlap,
            empty_page_units=empty_pdf_page_units,
        )
    else:
        records = split_docx(
            src=src,
            out_dir=out_dir,
            max_units=max_units,
            unit_mode=unit_mode,
            max_mb=max_mb,
            overlap_blocks=overlap,
        )

    write_manifest(out_dir, records)
    return out_dir, records


# ---------------------------------------------------------------------------
# GUI
# ---------------------------------------------------------------------------

def run_gui() -> None:
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    root = tk.Tk()
    root.title(f"{APP_NAME} {APP_VERSION}")
    root.geometry("820x620")
    root.minsize(760, 560)

    files: List[Path] = []

    outer = ttk.Frame(root, padding=14)
    outer.pack(fill="both", expand=True)

    title = ttk.Label(
        outer, text="NotebookLM Splitter",
        font=("Segoe UI", 16, "bold")
    )
    title.pack(anchor="w")
    ttk.Label(
        outer,
        text=(
            "PDF/DOCXをNotebookLM向けに分割します。"
            "PDFはページ境界、DOCXは見出し・段落/表境界を優先します。"
        ),
    ).pack(anchor="w", pady=(2, 10))

    file_frame = ttk.LabelFrame(outer, text="入力ファイル", padding=8)
    file_frame.pack(fill="both", expand=True)

    listbox = tk.Listbox(file_frame, height=9, selectmode=tk.EXTENDED)
    listbox.pack(side="left", fill="both", expand=True)
    sb = ttk.Scrollbar(file_frame, orient="vertical", command=listbox.yview)
    sb.pack(side="left", fill="y")
    listbox.configure(yscrollcommand=sb.set)

    btns = ttk.Frame(file_frame)
    btns.pack(side="left", fill="y", padx=(8, 0))

    def refresh_list():
        listbox.delete(0, tk.END)
        for p in files:
            listbox.insert(tk.END, str(p))

    def add_files():
        chosen = filedialog.askopenfilenames(
            title="PDF / DOCX を選択",
            filetypes=[
                ("PDF / Word", "*.pdf *.docx"),
                ("PDF", "*.pdf"),
                ("Word", "*.docx"),
                ("All files", "*.*"),
            ],
        )
        existing = {str(p.resolve()) for p in files}
        for x in chosen:
            p = Path(x)
            if p.suffix.lower() in {".pdf", ".docx"}:
                rp = str(p.resolve())
                if rp not in existing:
                    files.append(p)
                    existing.add(rp)
        refresh_list()

    def remove_selected():
        sel = list(listbox.curselection())
        for i in reversed(sel):
            files.pop(i)
        refresh_list()

    ttk.Button(btns, text="追加...", command=add_files).pack(fill="x")
    ttk.Button(btns, text="選択を削除", command=remove_selected).pack(fill="x", pady=(6, 0))
    ttk.Button(btns, text="全消去", command=lambda: (files.clear(), refresh_list())).pack(fill="x", pady=(6, 0))

    settings = ttk.LabelFrame(outer, text="分割設定", padding=10)
    settings.pack(fill="x", pady=(10, 0))

    row1 = ttk.Frame(settings)
    row1.pack(fill="x")
    ttk.Label(row1, text="カウント方式:").pack(side="left")
    mode_var = tk.StringVar(value="tokens")
    mode_combo = ttk.Combobox(
        row1, textvariable=mode_var, state="readonly", width=18,
        values=("tokens", "words", "chars")
    )
    mode_combo.pack(side="left", padx=(6, 16))
    ttk.Label(row1, text="1パート上限:").pack(side="left")
    max_var = tk.StringVar(value=str(DEFAULT_MAX_UNITS))
    ttk.Entry(row1, textvariable=max_var, width=12).pack(side="left", padx=(6, 16))
    ttk.Label(row1, text="ファイル上限(MB):").pack(side="left")
    maxmb_var = tk.StringVar(value=str(int(DEFAULT_MAX_MB)))
    ttk.Entry(row1, textvariable=maxmb_var, width=8).pack(side="left", padx=(6, 0))

    row2 = ttk.Frame(settings)
    row2.pack(fill="x", pady=(8, 0))
    ttk.Label(row2, text="重複数:").pack(side="left")
    overlap_var = tk.StringVar(value="0")
    ttk.Entry(row2, textvariable=overlap_var, width=8).pack(side="left", padx=(6, 6))
    ttk.Label(
        row2,
        text="（PDF=ページ数、DOCX=段落/表ブロック数。通常は0推奨）"
    ).pack(side="left")

    row3 = ttk.Frame(settings)
    row3.pack(fill="x", pady=(8, 0))
    ttk.Label(row3, text="文字抽出できないPDFページの推定units/ページ:").pack(side="left")
    empty_var = tk.StringVar(value=str(DEFAULT_EMPTY_PDF_PAGE_UNITS))
    ttk.Entry(row3, textvariable=empty_var, width=10).pack(side="left", padx=(6, 0))

    out_frame = ttk.Frame(settings)
    out_frame.pack(fill="x", pady=(8, 0))
    ttk.Label(out_frame, text="出力先:").pack(side="left")
    out_var = tk.StringVar(value=str(Path.home() / "Documents" / "NotebookLM_Split"))
    out_entry = ttk.Entry(out_frame, textvariable=out_var)
    out_entry.pack(side="left", fill="x", expand=True, padx=(6, 6))

    def choose_out():
        d = filedialog.askdirectory(title="出力フォルダ")
        if d:
            out_var.set(d)

    ttk.Button(out_frame, text="参照...", command=choose_out).pack(side="left")

    info = ttk.Label(
        outer,
        text=(
            "tokens はGeminiの正確なトークナイザではなく安全寄りの概算です。"
            "NotebookLMの通常ソース上限に余裕を持たせるため、既定値は350,000です。"
        ),
        wraplength=780,
    )
    info.pack(anchor="w", pady=(10, 0))

    status_var = tk.StringVar(value="準備完了")
    status = ttk.Label(outer, textvariable=status_var)
    status.pack(anchor="w", pady=(10, 0))

    progress = ttk.Progressbar(outer, mode="determinate")
    progress.pack(fill="x", pady=(4, 0))

    def do_split():
        if not files:
            messagebox.showwarning(APP_NAME, "PDFまたはDOCXを追加してください。")
            return
        try:
            max_units = int(max_var.get().replace(",", "").strip())
            max_mb = float(maxmb_var.get().strip())
            overlap = int(overlap_var.get().strip())
            empty_units = int(empty_var.get().replace(",", "").strip())
            if max_units <= 0 or max_mb <= 0 or overlap < 0 or empty_units < 0:
                raise ValueError
        except ValueError:
            messagebox.showerror(APP_NAME, "設定値を確認してください。")
            return

        parent = Path(out_var.get()).expanduser()
        parent.mkdir(parents=True, exist_ok=True)
        progress["maximum"] = len(files)
        progress["value"] = 0
        errors = []
        summaries = []

        root.config(cursor="watch")
        root.update_idletasks()
        try:
            for i, src in enumerate(files, 1):
                status_var.set(f"処理中 ({i}/{len(files)}): {src.name}")
                root.update()
                try:
                    out_dir, records = process_file(
                        src=src,
                        parent_output=parent,
                        max_units=max_units,
                        unit_mode=mode_var.get(),
                        max_mb=max_mb,
                        overlap=overlap,
                        empty_pdf_page_units=empty_units,
                    )
                    summaries.append(f"{src.name}: {len(records)} parts -> {out_dir}")
                except Exception as e:
                    errors.append(f"{src.name}: {e}")
                progress["value"] = i
                root.update_idletasks()
        finally:
            root.config(cursor="")
            status_var.set("完了" if not errors else "完了（一部エラーあり）")

        msg = "\n".join(summaries)
        if errors:
            msg += ("\n\nエラー:\n" + "\n".join(errors))
            messagebox.showwarning(APP_NAME, msg)
        else:
            messagebox.showinfo(APP_NAME, msg or "完了しました。")

    ttk.Button(
        outer, text="分割開始", command=do_split
    ).pack(anchor="e", pady=(10, 0), ipadx=18, ipady=4)

    root.mainloop()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_arg_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Split PDF/DOCX into NotebookLM-friendly chunks."
    )
    p.add_argument("files", nargs="*", type=Path, help="Input PDF/DOCX file(s)")
    p.add_argument("-o", "--output", type=Path, default=Path.cwd() / "NotebookLM_Split")
    p.add_argument("--mode", choices=("tokens", "words", "chars"), default="tokens")
    p.add_argument("--max-units", type=int, default=DEFAULT_MAX_UNITS)
    p.add_argument("--max-mb", type=float, default=DEFAULT_MAX_MB)
    p.add_argument("--overlap", type=int, default=0)
    p.add_argument("--empty-pdf-page-units", type=int, default=DEFAULT_EMPTY_PDF_PAGE_UNITS)
    p.add_argument("--gui", action="store_true", help="Open GUI")
    p.add_argument("--version", action="version", version=f"%(prog)s {APP_VERSION}")
    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_arg_parser().parse_args(argv)

    if args.gui or not args.files:
        run_gui()
        return 0

    args.output.mkdir(parents=True, exist_ok=True)
    had_error = False

    for src in args.files:
        try:
            out_dir, records = process_file(
                src=src,
                parent_output=args.output,
                max_units=args.max_units,
                unit_mode=args.mode,
                max_mb=args.max_mb,
                overlap=args.overlap,
                empty_pdf_page_units=args.empty_pdf_page_units,
            )
            print(f"[OK] {src} -> {out_dir} ({len(records)} parts)")
        except Exception as e:
            had_error = True
            print(f"[ERROR] {src}: {e}", file=sys.stderr)

    return 1 if had_error else 0


if __name__ == "__main__":
    raise SystemExit(main())
